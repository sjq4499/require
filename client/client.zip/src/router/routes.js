export default [{
    path: '/'
}]