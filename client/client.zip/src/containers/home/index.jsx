import React, { Component } from 'react'
import { connect } from 'dva'
import Wraper from '@/components/layout'

class Home extends Component {
    render() {
        return <Wraper>
            this is home page
        </Wraper>
    }
}
export default Home;