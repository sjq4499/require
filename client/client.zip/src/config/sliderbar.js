export const sliderBar = [{
    id: "home",
    name: "首页",
    path: "/",
    icon: "video-camera",
    children: [{
        id: "home111",
        name: "首页66",
        path: "/",
        icon: "video-camera",
    }]
},
{
    id: "order",
    name: "订单管理",
    path: "/",
    icon: "video-camera"
},
{
    id: "fanance",
    name: "财务管理",
    path: "/",
    icon: "video-camera"
},
{
    id: "coperation",
    name: "组织架构",
    path: "/",
    icon: "upload"
}]