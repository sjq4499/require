# nodejs 路径

- __dirnmae 获取当前文件所在路劲
- process.cwd() 获得当前命令行程序所在的路径